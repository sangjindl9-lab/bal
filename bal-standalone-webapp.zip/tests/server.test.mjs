import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import net from 'node:net';
test('Independent login, staff access, shared records, revocation and restart durability',async()=>{
const dir=await mkdtemp(path.join(tmpdir(),'bal-test-'));
const probe=net.createServer();await new Promise(r=>probe.listen(0,'127.0.0.1',r));const port=probe.address().port;await new Promise(r=>probe.close(r));
const base='http://127.0.0.1:'+port, password=randomBytes(20).toString('hex');let proc;
async function start(){proc=spawn(process.execPath,['server.mjs'],{env:{...process.env,PORT:String(port),DATA_DIR:dir,ADMIN_USERNAME:'admin',ADMIN_PASSWORD:password,NODE_ENV:'test'},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('start timeout')),10000);proc.stdout.on('data',d=>{if(d.toString().includes('listening')){clearTimeout(timer);resolve()}});proc.on('exit',c=>{clearTimeout(timer);reject(Error('server exited '+c))})})}
async function stop(){const p=proc;await new Promise(r=>{p.once('exit',r);p.kill('SIGTERM')})}
async function call(route,method='GET',data,session='',origin=base){const res=await fetch(base+route,{method,headers:{origin,'Content-Type':'application/json',cookie:session},...(data?{body:JSON.stringify(data)}:{})});return{status:res.status,data:await res.json(),cookie:res.headers.get('set-cookie')?.split(';')[0]}}
try{await start();assert.equal((await call('/api/records')).status,401);assert.equal((await call('/api/login','POST',{username:'admin',password:'wrong'})).status,401);
const a=await call('/api/login','POST',{username:'admin',password});assert.equal(a.status,200);const admin=a.cookie;
assert.equal((await call('/api/records','POST',{items:[]},admin,'https://foreign.test')).status,403);
const temp=randomBytes(20).toString('hex'),fresh=randomBytes(20).toString('hex');assert.equal((await call('/api/users','POST',{username:'staff1',name:'직원1',password:temp},admin)).status,201);
const s=await call('/api/login','POST',{username:'staff1',password:temp});const staff=s.cookie;assert.equal(s.data.mustChange,true);assert.equal((await call('/api/records','GET',null,staff)).status,403);
assert.equal((await call('/api/password','POST',{current:temp,password:fresh},staff)).status,200);
assert.equal((await call('/api/users','GET',null,staff)).status,403);
const material={id:'m1',kind:'materials',name:'자재',price:100};assert.equal((await call('/api/records','POST',{items:[material]},admin)).status,200);
let list=await call('/api/records','GET',null,staff);assert.equal(list.data[0].name,'자재');const prior=list.data[0];
await new Promise(r=>setTimeout(r,5));assert.equal((await call('/api/records','POST',{items:[{...prior,price:200}]},staff)).status,200);assert.equal((await call('/api/records','POST',{items:[{...prior,price:300}]},admin)).status,409);
assert.equal((await call('/api/records','POST',{items:[{...material,id:'bad',price:-1}]},staff)).status,400);
assert.equal((await call('/api/backup','GET',null,staff)).status,403);assert.equal((await call('/api/backup','GET',null,admin)).data.items.length,1);
const people=await call('/api/users','GET',null,admin),person=people.data.find(u=>u.username==='staff1');await call('/api/users','PATCH',{id:person.id,active:false},admin);assert.equal((await call('/api/records','GET',null,staff)).status,401);
await stop();await start();assert.equal((await call('/api/records','GET',null,admin)).data[0].price,200);
assert.equal((await call('/api/records','DELETE',{id:'m1'},admin)).status,200);await call('/api/logout','POST',{},admin);assert.equal((await call('/api/me','GET',null,admin)).status,401);
}finally{if(proc&&!proc.killed)await stop();await rm(dir,{recursive:true,force:true})}
});
